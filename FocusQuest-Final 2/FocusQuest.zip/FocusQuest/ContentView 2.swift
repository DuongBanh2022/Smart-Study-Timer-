import SwiftUI
import Combine
import UserNotifications
import AVFoundation

struct ContentView: View {
    
    // MARK: - Timer Settings
    @State private var pomodoroLength = 25
    @State private var shortBreakLength = 5
    @State private var longBreakLength = 15
    
    // MARK: - Timer State
    @State private var timeRemaining = 25 * 60
    @State private var totalTime = 25 * 60
    @State private var timerRunning = false
    @State private var currentMode = "Pomodoro"
    
    // MARK: - XP System
    @State private var xp = 0
    
    // MARK: - Loop State
    @State private var isLooping = false
    @State private var loopStep = 0
    @State private var loopPhase = "Pomodoro"
    
    // MARK: - Navigation
    @State private var showingCustomSettings = false
    
    // MARK: - Stats
    @State private var sessionsCompleted = 0
    @State private var streak = 0
    @State private var showingStats = false
    
    // MARK: - Sound
    @State private var audioPlayer: AVAudioPlayer?
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack(spacing: 25) {
            
            // MODE BUTTONS
            HStack(spacing: 10) {
                modeButton("Pomodoro")
                modeButton("Short Break")
                modeButton("Long Break")
                modeButton("Loop")
            }
            
            Button("Custom Timer") {
                showingCustomSettings = true
            }
            .buttonStyle(.bordered)
            
            Button("View Stats") {
                showingStats = true
            }
            .buttonStyle(.borderedProminent)
            
            // XP DISPLAY
            Text("XP: \(xp)")
                .font(.headline)
                .padding(6)
                .background(Color.yellow.opacity(0.2))
                .clipShape(Capsule())
            
            // MODE LABEL
            Text(isLooping ? "\(loopPhase) (\(loopStep)/4)" : currentMode)
                .font(.title)
                .fontWeight(.bold)
            
            // PROGRESS RING
            ZStack {
                Circle()
                    .stroke(Color.gray.opacity(0.2), lineWidth: 10)
                
                Circle()
                    .trim(from: 0, to: CGFloat(timeRemaining) / CGFloat(totalTime))
                    .stroke(Color.blue, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .animation(.linear(duration: 1), value: timeRemaining)
                
                Text(formatTime(timeRemaining))
                    .font(.system(size: 40, design: .monospaced))
            }
            .frame(width: 200, height: 200)
            
            // CONTROL BUTTONS
            HStack(spacing: 40) {
                
                Button {
                    timerRunning.toggle()
                } label: {
                    Image(systemName: timerRunning ? "pause.fill" : "play.fill")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 60, height: 60)
                        .background(Color.blue)
                        .clipShape(Circle())
                }
                
                Button {
                    resetTimer()
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.title)
                        .foregroundColor(.white)
                        .frame(width: 60, height: 60)
                        .background(Color.gray)
                        .clipShape(Circle())
                }
            }
        }
        .padding()
        
        // TIMER LOGIC
        .onReceive(timer) { _ in
            guard timerRunning else { return }
            
            if timeRemaining > 0 {
                timeRemaining -= 1
            } else {
                
                playSound(for: currentMode)
                
                sendNotification()
                
                // XP + STATS (Pomodoro only)
                if (!isLooping && currentMode == "Pomodoro") ||
                   (isLooping && loopPhase == "Pomodoro") {
                    
                    withAnimation {
                        xp += 25
                        sessionsCompleted += 1
                        streak += 1
                    }
                }
                
                if isLooping {
                    nextLoopStep()
                } else {
                    timerRunning = false
                }
            }
        }
        
        // SETTINGS
        .sheet(isPresented: $showingCustomSettings) {
            CustomSettingsView(
                pomodoroLength: $pomodoroLength,
                shortBreakLength: $shortBreakLength,
                longBreakLength: $longBreakLength,
                onSave: { resetTimer() }
            )
        }
        
        // STATS
        .sheet(isPresented: $showingStats) {
            StatsView(
                xp: xp,
                sessions: sessionsCompleted,
                streak: streak
            )
        }
        
        .onAppear {
            requestNotificationPermission()
        }
    }
    
    // MARK: - SOUND FUNCTION
    func playSound(for mode: String) {
        var soundName = "pomodoro"
        
        if isLooping {
            switch loopPhase {
            case "Pomodoro": soundName = "pomodoro"
            case "Short Break": soundName = "short"
            case "Long Break": soundName = "long"
            default: soundName = "loop"
            }
        } else {
            switch mode {
            case "Pomodoro": soundName = "pomodoro"
            case "Short Break": soundName = "short"
            case "Long Break": soundName = "long"
            case "Loop": soundName = "loop"
            default: break
            }
        }
        
        if let url = Bundle.main.url(forResource: soundName, withExtension: "mp3") {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
            } catch {
                print("Sound error")
            }
        }
    }
    
    // MARK: - NOTIFICATION
    func sendNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Timer Finished!"
        content.body = "Session complete 🎉"
        content.sound = .default
        
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: nil
        )
        
        UNUserNotificationCenter.current().add(request)
    }
    
    func requestNotificationPermission() {
        UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }
    
    // MARK: - MODE BUTTON
    func modeButton(_ title: String) -> some View {
        Button(title) {
            isLooping = false
            
            switch title {
            case "Pomodoro":
                switchMode("Pomodoro", duration: pomodoroLength)
            case "Short Break":
                switchMode("Short Break", duration: shortBreakLength)
            case "Long Break":
                switchMode("Long Break", duration: longBreakLength)
            case "Loop":
                isLooping = true
                startLoop()
            default:
                break
            }
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(currentMode == title ? Color.blue : Color.gray.opacity(0.2))
        .foregroundColor(currentMode == title ? .white : .black)
        .clipShape(Capsule())
    }
    
    // MARK: - MODE FUNCTIONS
    func switchMode(_ mode: String, duration: Int) {
        currentMode = mode
        timerRunning = false
        timeRemaining = duration * 60
        totalTime = duration * 60
    }
    
    func resetTimer() {
        timerRunning = false
        
        if isLooping {
            startLoop()
            return
        }
        
        switch currentMode {
        case "Pomodoro":
            timeRemaining = pomodoroLength * 60
            totalTime = pomodoroLength * 60
        case "Short Break":
            timeRemaining = shortBreakLength * 60
            totalTime = shortBreakLength * 60
        case "Long Break":
            timeRemaining = longBreakLength * 60
            totalTime = longBreakLength * 60
        default:
            break
        }
    }
    
    // MARK: - LOOP LOGIC
    func startLoop() {
        loopStep = 1
        currentMode = "Loop"
        loopPhase = "Pomodoro"
        timeRemaining = pomodoroLength * 60
        totalTime = pomodoroLength * 60
        timerRunning = true
    }
    
    func nextLoopStep() {
        if loopPhase == "Pomodoro" {
            if loopStep == 4 {
                loopPhase = "Long Break"
                timeRemaining = longBreakLength * 60
                totalTime = longBreakLength * 60
            } else {
                loopPhase = "Short Break"
                timeRemaining = shortBreakLength * 60
                totalTime = shortBreakLength * 60
            }
        } else {
            if loopStep == 4 {
                playSound(for: "Loop") // loop end sound
                isLooping = false
                timerRunning = false
                return
            }
            loopStep += 1
            loopPhase = "Pomodoro"
            timeRemaining = pomodoroLength * 60
            totalTime = pomodoroLength * 60
        }
    }
    
    // MARK: - UTIL
    func formatTime(_ seconds: Int) -> String {
        let m = seconds / 60
        let s = seconds % 60
        return String(format: "%02d:%02d", m, s)
    }
}
